
<?php 
include '../db.php'; 
session_start();

if(isset($_POST['submit'])) {
    // Trim and sanitize inputs
    $name = trim($_POST['name']);
    $password = trim($_POST['password']);
    $email = trim($_POST['email']);
    $contact = trim($_POST['contact']);
    $intake = trim($_POST['intake']);
    $type = trim($_POST['type']);

    // Error array
    $error = [];

    // Validation checks
    if ($name == '') $error[] = "Name is required!";
    if ($password == '') $error[] = "Password is required!";
    if ($email == '') $error[] = "Email is required!";
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $error[] = "Invalid email format!";
    if ($intake == '') $error[] = "Intake cannot be empty!";
    if ($contact == '') $error[] = "Contact is required!";
    elseif (!preg_match('/^[0-9]{10}$/', $contact)) $error[] = "Contact must be exactly 10 digits!";
    if ($type == '') $error[] = "Job type is required!";

    if (!empty($error)) {
        echo "<script>alert('" . implode("\\n", $error) . "');</script>";
    } else {
        // Check if email already exists
        $check_query = "SELECT * FROM companies WHERE email = ?";
        $stmt = mysqli_prepare($connection, $check_query);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            echo "<script>alert('Email already registered!');</script>";
        } else {
            // Secure password hashing
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            // Prepare SQL query
            $query = "INSERT INTO companies (name, email, contact, intake, password, type) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($connection, $query);

            if (!$stmt) {
                die("Database error: " . mysqli_error($connection));
            }

            mysqli_stmt_bind_param($stmt, "ssssss", $name, $email, $contact, $intake, $hashed_password, $type);
            $result = mysqli_stmt_execute($stmt);

            if (!$result) {
                die("Error in Registration: " . mysqli_error($connection));
            } else {
                echo "<script>alert('Registration Successful! Redirecting to Login Page...');</script>";
                echo "<script>window.location.href='login.php';</script>";
                exit();
            }

            mysqli_stmt_close($stmt);
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico" type="image/icon">
    <link rel="icon" href="favicon.ico" type="image/icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Company Registration</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="../css/style.css">
</head>
<body class="light-gray-bg">

    <div class="templatemo-content-widget templatemo-login-widget white-bg">
        <header class="text-center">
            <div class="square"></div>
            <h1>Company Registration</h1>
        </header>
        <form method="POST" class="templatemo-login-form" action="register.php">
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-user fa-fw"></i></div>
                    <input type="text" name="name" class="form-control" placeholder="Company Name" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon">@</div>
                    <input type="email" name="email" class="form-control" placeholder="Company Email" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-phone fa-fw"></i></div>
                    <input type="text" name="contact" class="form-control" placeholder="Contact Number" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-key fa-fw"></i></div>
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon">#</div>
                    <input type="text" name="intake" class="form-control" placeholder="Intake (e.g., 2025)" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon">J</div>
                    <input type="text" name="type" class="form-control" placeholder="Job Type (e.g., IT, Finance)" required>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="templatemo-blue-button width-100">Register</button>
            </div>
        </form>
    </div>

    <div class="templatemo-content-widget templatemo-login-widget templatemo-register-widget white-bg">
        <p>Have an Account? <strong><a href="login.php" class="blue-text">Sign in here!</a></strong></p>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>
