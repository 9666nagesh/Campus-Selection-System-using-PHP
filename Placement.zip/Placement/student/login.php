<?php 
include '../db.php'; 
session_start(); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Trim and sanitize input
    $sapid = trim($_POST['sapid']);
    $the_password = trim($_POST['password']);

    // Check if input is empty
    if (empty($sapid) || empty($the_password)) {
        echo "<script>alert('SAP ID and Password are required!');</script>";
    } else {
        // Fetch user details from database
        $query = "SELECT * FROM student WHERE sapid = ?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, "s", $sapid);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        // Check if a row is found
        if ($row = mysqli_fetch_assoc($result)) {
            $db_password = $row['password'];
            $db_sapid = $row['sapid'];
            $db_name = $row['name'];

            // Verify password using password_hash() function
            if (password_verify($the_password, $db_password)) {
                // Authentication successful
                $_SESSION['name'] = $db_name;
                $_SESSION['sapid'] = $db_sapid;
                header("Location: hello.php");
                exit();
            } else {
                echo "<script>alert('Invalid SAP ID or Password!');</script>";
            }
        } else {
            echo "<script>alert('User not found!');</script>";
        }
        
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/templatemo-style.css">
</head>
<body class="light-gray-bg">
    <div class="templatemo-content-widget templatemo-login-widget white-bg">
        <header class="text-center">
            <div class="square"></div>
            <h1>Student Login</h1>
        </header>
        <form action="login.php" method="POST" class="templatemo-login-form">
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-user fa-fw"></i></div>
                    <input type="text" class="form-control" placeholder="SAP ID" name="sapid" required>
                </div>
            </div>
            <div class="form-group">
                <div class="input-group">
                    <div class="input-group-addon"><i class="fa fa-key fa-fw"></i></div>
                    <input type="password" class="form-control" placeholder="******" name="password" required>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="templatemo-blue-button width-100">Login</button>
            </div>
        </form>
    </div>
    <div class="templatemo-content-widget templatemo-login-widget templatemo-register-widget white-bg">
        <p>Not a registered user yet? <strong><a href="register.php" class="blue-text">Sign up now!</a></strong></p>
    </div>
</body>
</html>
