<?php 
session_start(); 
include '../db.php'; 

// Ensure session variable is set
if (!isset($_SESSION['sapid'])) {
    die("Error: User not logged in.");
}

$sapid = mysqli_real_escape_string($connection, $_SESSION['sapid']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!--favicon-->
    <link rel="shortcut icon" href="favicon.ico" type="image/icon">
    <link rel="icon" href="favicon.ico" type="image/icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>

    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/templatemo-style.css" rel="stylesheet">
</head>
<body>
<div class="templatemo-flex-row">
    <div class="templatemo-sidebar">
        <header class="templatemo-site-header">
            <div class="square"></div>
            <?php
            $Welcome = "Welcome";
            echo "<h1>" . $Welcome . ",<br>" . htmlspecialchars($_SESSION['name']) . "</h1><br>";
            ?>
        </header>
        <nav class="templatemo-left-nav">
            <ul>
                <li><a href="hello.php"><i class="fa fa-fw"></i>Dashboard</a></li>
                <li><a href="clist.php"><i class="fa fa-fw"></i>Companies</a></li>
                <li><a href="applied_comp.php" class="active"><i class="fa fa-fw"></i>Applied Companies</a></li>
                <li><a href="s_eligibility.php"><i class="fa fa-fw"></i>Students Eligibility</a></li>
                <li><a href="logout.php"><i class="fa fa-fw"></i>Sign Out</a></li>
            </ul>
        </nav>
    </div>

    <div class="templatemo-content col-1 light-gray-bg">
        <div class="templatemo-content-container">
            <div class="templatemo-content-widget no-padding">
                <a href="bgo.php" class="templatemo-blue-button">Companies list</a>
                <div class="panel panel-default table-responsive">
                    <?php
                    $query = "SELECT * FROM applied_comp WHERE sapid = '$sapid'";
                    $result = mysqli_query($connection, $query);

                    if (!$result) {
                        die("Query failed: " . mysqli_error($connection));
                    }

                    while ($row = mysqli_fetch_assoc($result)) {
                        $cc_id = $row['c_id'];
                        $mquery = "SELECT * FROM companies WHERE c_id = '$cc_id'";
                        $company_result = mysqli_query($connection, $mquery);

                        if (!$company_result) {
                            die("Query failed: " . mysqli_error($connection));
                        }

                        while ($company = mysqli_fetch_assoc($company_result)) {
                            ?>
                            <div class="panel panel-default table-responsive"
                                 style="border:2px solid cyan;padding:10px;margin:10px;box-shadow:3px 3px">
                                <h1 style="text-decoration:underline"><b><?php echo htmlspecialchars($company['name']); ?></b></h1>
                                <p><b>Email:</b> <?php echo htmlspecialchars($company['email']); ?></p>
                                <p><b>Contact:</b> <?php echo htmlspecialchars($company['contact']); ?></p>
                                <p><b>Intake:</b> <?php echo htmlspecialchars($company['intake']); ?></p>
                                <p><b>Company Id:</b> <?php echo htmlspecialchars($cc_id); ?></p>
                                <p><b>Job type:</b> <?php echo htmlspecialchars($company['type']); ?></p>
                            </div>
                            <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
