<?php 
session_start(); 
include './db.php'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Current Drives</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 50px;
        }
        .table thead {
            background-color: #007bff;
            color: white;
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        .card {
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4"><i class="fas fa-building"></i> Current Drives</h2>
    
    <div class="card p-4">
        <table class="table table-striped table-hover text-center">
            <thead>
                <tr>
                    <th>Company Name</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Intake</th>
                    <th>Selected</th>
                    <th>Remaining Positions</th>
                    <th>Job Type</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $query = "SELECT companies.*, 
                                 (SELECT COUNT(*) FROM selected_stud WHERE selected_stud.c_id = companies.c_id) AS selected 
                          FROM companies";

                $result = mysqli_query($connection, $query);

                if (!$result) {
                    die("Query Failed: " . mysqli_error($connection));
                }

                while ($row = mysqli_fetch_assoc($result)) {
                    $remaining_positions = $row['intake'] - $row['selected'];
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['contact']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo $row['intake']; ?></td>
                        <td><?php echo $row['selected']; ?></td>
                        <td><b class="text-<?php echo ($remaining_positions > 0) ? 'success' : 'danger'; ?>">
                            <?php echo max($remaining_positions, 0); ?>
                        </b></td>
                        <td><?php echo htmlspecialchars($row['type']); ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
