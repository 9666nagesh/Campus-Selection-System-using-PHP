-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 20, 2025 at 12:31 PM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(32) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`, `dept`, `id`) VALUES
('computer@djsce.com', '12fH.DuHowWHk', 'Computer', 7),
('chemical@djsce.com', '12caNGmeSAnzs', 'Chemical', 8),
('extc@djsce.com', '12UFVExxCBiZQ', 'EXTC', 9),
('mechanical@djsce.com', '12Tm4EsIVkNZo', 'Mechanical', 10),
('it@djsce.com', '12.s1443X0ivA', 'IT', 11),
('cse@gmail.com', '12tir.zIbWQ3c', 'Computer', 12),
('it@gmail.com', '12vjy8B6VZQUU', 'IT', 13);

-- --------------------------------------------------------

--
-- Table structure for table `applied_comp`
--

DROP TABLE IF EXISTS `applied_comp`;
CREATE TABLE IF NOT EXISTS `applied_comp` (
  `c_id` int(255) NOT NULL,
  `sapid` bigint(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applied_comp`
--

INSERT INTO `applied_comp` (`c_id`, `sapid`, `id`) VALUES
(19, 600061, 41),
(19, 600028, 42),
(19, 700028, 43),
(19, 900063, 44),
(19, 700033, 45),
(19, 800011, 57),
(19, 800063, 58),
(19, 700096, 59),
(19, 74859, 60),
(23, 600060, 62),
(24, 600060, 63),
(18, 600061, 64),
(2, 777888, 66),
(1, 123456, 67),
(2, 123456, 68);

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
CREATE TABLE IF NOT EXISTS `companies` (
  `contact` varchar(25) NOT NULL,
  `name` varchar(25) NOT NULL,
  `intake` int(25) NOT NULL,
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`c_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`contact`, `name`, `intake`, `c_id`, `email`, `password`, `type`) VALUES
('9988776655', 'BITS TECHNOLOGIES', 40, 1, 'bitstech@gmail.com', '$2y$10$1uAB0MmR1GlusR3QoU88FuvJqrFhgOkrnO55dyHe7c8uGRM7wQES6', 'Developer'),
('9998887770', 'BTC Company', 25, 2, 'btc@gmail.com', '$2y$10$C7ou76tyGeipljXNvxfnlOGHkuNYbfXBFlGHTOlR9v0UiA7QtL26W', 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `selected_stud`
--

DROP TABLE IF EXISTS `selected_stud`;
CREATE TABLE IF NOT EXISTS `selected_stud` (
  `sapid` int(255) NOT NULL,
  `c_id` int(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `selected_stud`
--

INSERT INTO `selected_stud` (`sapid`, `c_id`, `id`) VALUES
(600060, 19, 36),
(600061, 19, 37),
(700033, 19, 39),
(600061, 18, 41),
(900063, 19, 42),
(777888, 1, 43),
(777888, 2, 44),
(123456, 1, 45);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `email` varchar(25) NOT NULL,
  `s_id` int(25) NOT NULL AUTO_INCREMENT,
  `cgpa` float DEFAULT NULL,
  `dept` varchar(25) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(15) DEFAULT NULL,
  `name` varchar(25) NOT NULL,
  `sapid` bigint(25) DEFAULT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`email`, `s_id`, `cgpa`, `dept`, `password`, `contact`, `name`, `sapid`) VALUES
('parthm@gmail.com', 70, 8.9, 'Mechanical', '12rxtfbHZSO6w', '14526', 'Parth Mehta', 600060),
('pujanm@ymail.com', 71, 8.89, 'EXTC', '125956kRHNmN6', '15498', 'Pujan Mehta ', 600061),
('ayush@hotmail.com', 72, 6.9, 'Chemical', '12Txmv.wKwQjQ', '16582', 'Ayush Kothari', 600051),
('jimit@outlook.com', 75, 6.3, 'Chemical', '12eCdhhNbNwFI', '15986', 'Jimit Gandhi', 600028),
('mahima@yahoo.com', 78, 6.5, 'IT', '12kJMfvBYkMoI', '74125', 'Mahima Gupta', 700033),
('aashi@gmail.com', 80, 5.6, 'IT', '12cbLRsKzzWPU', '85236', 'Aashi Dani', 700028),
('raj@gmail.com', 81, 5.6, 'IT', '121QLbZwEa14I', '63258', 'Raj Kothari', 800011),
('navkar@gmail.com', 82, 7.3, 'IT', '125WQYPtLTbew', '32569', 'Navkar Shah', 800063),
('manali@gmail.com', 83, 6.5, 'IT', '12d9pV8/swG3k', '12536', 'Manali Vichare', 700096),
('kinjal@gmail.com', 84, 6.3, 'Mechanical', '12lqElmc1Ra72', '63528', 'Kinjal Lapasiya', 900063),
('riken@hotmail.com', 85, 5.6, 'Mechanical', '12BfSVejt3xeg', '25149', 'Riken Gala', 900636),
('aakash@ymail.com', 87, 6.3, 'Chemical', '12VXinmN0Gegc', '36259', 'Aakash Dhruva', 63985),
('sumit@ymail.com', 88, 6.3, 'Chemical', '12n9Kou2Fp7Cc', '85265', 'Sumit Goradia', 96327),
('vishwa@icloud.com', 89, 6.35, 'EXTC', '12iGCnuBwHLe2', '41529', 'Vishwa Shah', 74859),
('rachit@gmail.com', 90, 5.6, 'EXTC', '12E0WJIs8fLts', '632194', 'Rachit Doshi', 693581),
('riya@outlook.com', 91, 6.9, 'EXTC', '12i3pdHhtS10A', '74853', 'Riya Seth', 74125),
('praveen28wgl@gmail.com', 92, 9.88, 'Computer', '$2y$10$GTaf9.miC3t2UD/JvX69SOmMYZq4haZrYHuGIBVZDUBEcfvFai9PS', '9988998877', 'ankam praveen', 777888),
('sneha@gmail.com', 93, 8.98, 'Computer', '$2y$10$UUlORWHbftymYFjuzqFQ5esLZ6CpRI7ZYAMuaWwj.FmSfdjXu5.HG', '1234567890', 'snehalatha.A', 123456);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
